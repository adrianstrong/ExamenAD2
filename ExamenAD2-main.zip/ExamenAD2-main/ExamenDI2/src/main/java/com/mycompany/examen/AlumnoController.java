package com.mycompany.examen;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import models.Alumno;
import net.sf.jasperreports.engine.JRException;

public class AlumnoController implements Initializable {
    @FXML
    public TableColumn colNombre;
    @FXML
    public TableColumn colApellidos;
    @FXML
    public TableColumn colAD;
    @FXML
    public TableColumn colSGE;
    @FXML
    public TableColumn colDI;
    @FXML
    public TableColumn colPMDM;
    @FXML
    public TableColumn colEIE;
    @FXML
    public TableColumn colHLC;
    @FXML
    private TableView tblPrincipal;
    @FXML
    private Button anhadir;

    @FXML
    private Button salir;

    @FXML
    private Button imprimirpdf;

    @FXML
    private TextField inputNombre;

    @FXML
    private TextField inputApellido;

    @FXML
    private TextField inputAD;

    @FXML
    private TextField inputSGE;

    @FXML
    private TextField inputDI;

    @FXML
    private TextField inputPMDM;

    @FXML
    private TextField inputPSP;

    @FXML
    private TextField inputEIE;

    @FXML
    private TextField inputHLC;

    private Long id;

    @FXML
    private void verInforme(Alumno alumno) {
        try {
            Informe.pdfReport(alumno);
        } catch (JRException | ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AlumnoController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @FXML
    private void rellenarCampos() {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setHeaderText(null);
        alert.setTitle("ERROR");
        alert.setContentText("Debes de rellenar los campos");
        alert.showAndWait();
    }

    @FXML
    private void intervaloNotas() {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setHeaderText(null);
        alert.setTitle("ERROR");
        alert.setContentText("Las notas deben de estar entre 0 y 10");
        alert.showAndWait();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {


        colNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        colApellidos.setCellValueFactory(new PropertyValueFactory<>("apellidos"));
        colAD.setCellValueFactory(new PropertyValueFactory<>("AD"));
        colSGE.setCellValueFactory(new PropertyValueFactory<>("SGE"));
        colDI.setCellValueFactory(new PropertyValueFactory<>("DI"));
        colPMDM.setCellValueFactory(new PropertyValueFactory<>("PMDM"));
        colEIE.setCellValueFactory(new PropertyValueFactory<>("EIE"));
        colHLC.setCellValueFactory(new PropertyValueFactory<>("HLC"));


        Alumno a1 = new Alumno(1L, "Adrian", "Lopez", 2.0, 7.0, 8.0, 9.0, 5.0, 4.0);
        Alumno a2 = new Alumno(2L, "Pedro", "Rodriguez", 4.0, 9.0, 5.0, 5.0, 7.0, 6.0);
        Alumno a3 = new Alumno(3L, "Juan", "Espejo", 8.0, 9.0, 9.0, 10.0, 5.0, 3.0);

        fillTable(a1);
        fillTable(a2);
        fillTable(a3);

        id = 4L;
        anhadir.onMouseClickedProperty().set(event -> {
            crearAlumno();
            fillTable(crearAlumno());
        });

        tblPrincipal.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {

                Alumno alumnoSelec = new Alumno();

                alumnoSelec.setNombre((Alumno)(newSelection).getNombre());
                alumnoSelec.setAD((newSelection).getTelefono().toString());
                lblEmail.setText(((Empresa) newSelection).getEmail());
                lblResponsable.setText(((Empresa) newSelection).getResponsable());
                lblObs.setText(((Empresa) newSelection).getObservaciones());

            }
        });

    }

    public void fillTable(Alumno alumno) {
        tblPrincipal.getItems().add(alumno);
    }

    public Alumno crearAlumno(){

        if(Double.parseDouble(inputAD.getText()) > 0D || Double.parseDouble(inputAD.getText()) < 10D){
            intervaloNotas();
        }

        try {
            Alumno alumno = new Alumno(id,
                    inputNombre.getText(),
                    inputApellido.getText(),
                    Double.parseDouble(inputAD.getText()),
                    Double.parseDouble(inputSGE.getText()),
                    Double.parseDouble(inputDI.getText()),
                    Double.parseDouble(inputPMDM.getText()),
                    Double.parseDouble(inputEIE.getText()),
                    Double.parseDouble(inputHLC.getText()));
            return alumno;
        }catch(Exception e){
            rellenarCampos();
            return null;
        }


    }


}
