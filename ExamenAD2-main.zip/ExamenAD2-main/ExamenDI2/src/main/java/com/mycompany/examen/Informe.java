/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.examen;

import java.sql.SQLException;
import java.util.HashMap;

import models.Alumno;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;
import net.sf.jasperreports.export.SimplePdfExporterConfiguration;

/**
 *
 * @author FranciscoRomeroGuill
 */
public class Informe {

    public static void pdfReport(Alumno alumno) throws JRException, ClassNotFoundException, SQLException {
        HashMap hm = new HashMap();

        hm.put("nombre", alumno.getNombre());
        hm.put("apellidos", alumno.getNombre());
        hm.put("AD", alumno.getAD());
        hm.put("SGE", alumno.getSGE());
        hm.put("DI", alumno.getDI());
        hm.put("PMDM", alumno.getPMDM());
        hm.put("EIE", alumno.getEIE());
        hm.put("HLC", alumno.getHLC());


        JasperReport report = JasperCompileManager.compileReport("src/main/resources/report/notas.jrxml");

        JasperPrint jasperPrint = JasperFillManager.fillReport(
                report,
                hm,
                JdbcUtil.getConnection()
        );

        JRPdfExporter exp = new JRPdfExporter();
        exp.setExporterInput(new SimpleExporterInput(jasperPrint));
        exp.setExporterOutput(new SimpleOutputStreamExporterOutput("notas.pdf"));
        SimplePdfExporterConfiguration conf = new SimplePdfExporterConfiguration();
        exp.setConfiguration(conf);
        exp.exportReport();

        System.out.print("Done!");
    }

}
